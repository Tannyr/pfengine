"use strict"

const API = () => {
	log('API Initialized')	

	return {
		loadScene: Engine.loadScene
	}
}