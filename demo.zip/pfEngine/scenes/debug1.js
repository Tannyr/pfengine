"use strict"


//  Actions

const playerControls = function() {
  if (Key.isDown(Key.UP)) this.move("up")
  if (Key.isDown(Key.DOWN)) this.move("down")
  if (Key.isDown(Key.LEFT)) this.move("left")
  if (Key.isDown(Key.RIGHT)) this.move("right")
}


const logCollision = () => log("Collision detected")

//  Actors
const player = Entity("player", 16*4, 16*7, 16, 16, 2.5, "assets/guy.png", {update: playerControls})

//  Triggers
const collision = Entity("teleportToBottom", 16*3, 0, 64, 16, 0, null, {collision: logCollision})

//  SCENE  //
const debug1 = Scene("debug1", "assets/background.png", player, collision)

API().loadScene(debug1)
  	